

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/book")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String group = request.getParameter("group");
		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		int get = Integer.parseInt(request.getParameter("get"));
		String BK = request.getParameter("BK");
		String BC = request.getParameter("BC");
		String day = request.getParameter("day");
		String[] subject = request.getParameterValues("subject");
		String com = request.getParameter("com");
		
		response.setContentType("text/html");
		response.setCharacterEncoding("utf-8");
		request.setCharacterEncoding("utf-8");
		
		PrintWriter out = response.getWriter();
		
		out.print("<h3>도서 등록 결과</h3>");
		out.print("분류:" + group+"<br>");
		out.print("제목:" + name+ "<br>");
		out.print("가격:" + price+"<br>");
		out.print("수량:" + get+"<br>");
		out.print("저자:" + BK+"<br>");
		out.print("출판사:" + BC+"<br>");
		out.print("출판일:" + day+"<br>");
		for(String sub : subject) {
			out.println("선택한 과목:" +sub + "<br>");
		}
		out.print("주제:" + com +"<br>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		doGet(request, response);
	}

}
